// Percorso: /pages/files/index.js
// Scopo: File Dashboard con TreeView, batch upload con badge, tabella file
import { useState, useEffect } from "react";
import FilesTreeView from "../components/FilesTreeView";
import FileEditModal from "../components/FileEditModal";
import axios from "axios";

// --- COMPONENTE BATCH SELECTOR (identico a FileEditModal.js)
function BatchSelector({ label, items, selected, setSelected, color, badgeType }) {
  const [search, setSearch] = useState("");
  // Badge/filtra
  const filtered = items.filter(item => {
    const value = badgeType === "fullname"
      ? (item.surname ? item.surname + " " : "") + item.name
      : badgeType === "company"
        ? item.company
        : item.name || item.title;
    return value?.toLowerCase().includes(search.toLowerCase());
  });
  // Badge colori
  const colorMap = {
    green: { bg: "#e6f6ea", txt: "#147c3b" },
    blue: { bg: "#e3e6fa", txt: "#263b8a" },
    yellow: { bg: "#fff3d2", txt: "#a47319" },
    red: { bg: "#fce5e0", txt: "#a02222" },
    violet: { bg: "#e7e0fa", txt: "#563fa6" }
  };

  return (
    <div style={{ marginBottom: 9 }}>
      <label className="block text-sm font-semibold mb-1">{label}</label>
      <input
        type="text"
        placeholder={`Filtra ${label.toLowerCase()}...`}
        value={search}
        onChange={e => setSearch(e.target.value)}
        className="w-full mb-1 rounded px-2 py-1 border text-xs"
        style={{ borderColor: colorMap[color].bg }}
      />
      <div style={{ maxHeight: 120, overflowY: "auto", marginBottom: 6 }}>
        <div className="flex flex-wrap gap-2">
          {filtered.map(item => {
            const value = badgeType === "fullname"
              ? (item.surname ? item.surname + " " : "") + item.name
              : badgeType === "company"
                ? item.company
                : item.name || item.title;
            const isSelected = selected.some(s => s.id === item.id);
            return (
              <button
                key={item.id}
                type="button"
                className={`px-2 py-1 rounded-full text-xs font-semibold border`}
                style={{
                  background: isSelected ? colorMap[color].txt : colorMap[color].bg,
                  color: isSelected ? "#fff" : colorMap[color].txt,
                  borderColor: colorMap[color].bg,
                }}
                onClick={() => {
                  if (isSelected) setSelected(selected.filter(s => s.id !== item.id));
                  else setSelected([...selected, item]);
                }}
              >
                {value}
                {isSelected &&
                  <span style={{ marginLeft: 6, fontWeight: "bold", color: "#e22", cursor: "pointer" }}>×</span>
                }
              </button>
            );
          })}
        </div>
      </div>
      {/* Badge selezionati */}
      <div className="flex flex-wrap gap-2 mb-1">
        {selected.map(item => {
          const value = badgeType === "fullname"
            ? (item.surname ? item.surname + " " : "") + item.name
            : badgeType === "company"
              ? item.company
              : item.name || item.title;
          return (
            <span
              key={item.id}
              className={`px-2 py-1 rounded-full text-xs font-semibold border`}
              style={{ background: colorMap[color].bg, color: colorMap[color].txt }}
            >
              {value}
              <button
                className="ml-1 text-red-600 font-bold hover:text-red-900"
                type="button"
                onClick={() => setSelected(selected.filter(s => s.id !== item.id))}
                style={{ background: "transparent", border: "none", marginLeft: 8, cursor: "pointer" }}
                title="Rimuovi"
              >×</button>
            </span>
          );
        })}
      </div>
    </div>
  );
}

// --- FILE DASHBOARD PAGE ---
export default function FilesPage() {
  // TreeView stato
  const [selectedNode, setSelectedNode] = useState(null); // può essere cartella o file
  const [reloadFlag, setReloadFlag] = useState(false);

  // Batch upload stato
  const [batchFiles, setBatchFiles] = useState([]);
  const [uploading, setUploading] = useState(false);

  // Batch badge stato
  const [batchTags, setBatchTags] = useState([]);
  const [batchTeams, setBatchTeams] = useState([]);
  const [batchProjects, setBatchProjects] = useState([]);
  const [batchClients, setBatchClients] = useState([]);
  const [batchUsers, setBatchUsers] = useState([]);

  // Opzioni disponibili
  const [tags, setTags] = useState([]);
  const [teams, setTeams] = useState([]);
  const [projects, setProjects] = useState([]);
  const [clients, setClients] = useState([]);
  const [users, setUsers] = useState([]);

  // Carica opzioni disponibili all’avvio
  useEffect(() => {
    axios.get("/api/tags").then(res => setTags(res.data || []));
    axios.get("/api/teams").then(res => setTeams(res.data || []));
    axios.get("/api/projects").then(res => setProjects(res.data || []));
    axios.get("/api/clients").then(res => setClients(res.data || []));
    axios.get("/api/users").then(res => setUsers(res.data || []));
  }, []);

  // Handler drop/selection file multipli
  const handleFilesSelected = (e) => {
    const files = Array.from(e.target.files || e.dataTransfer.files || []);
    setBatchFiles(f => [...f, ...files]);
  };
  const removeBatchFile = (i) => {
    setBatchFiles(files => files.filter((_, idx) => idx !== i));
  };

  // Batch upload handler
  const handleBatchUpload = async () => {
    if (!selectedNode || !selectedNode.files) return alert("Seleziona una cartella di destinazione!");
    if (batchFiles.length === 0) return alert("Nessun file selezionato!");
    setUploading(true);

    try {
      const form = new FormData();
      batchFiles.forEach(f => form.append("files", f));
      form.append("folder_id", selectedNode.id);
      form.append("tags", JSON.stringify(batchTags.map(t => t.id)));
      form.append("teams", JSON.stringify(batchTeams.map(t => t.id)));
      form.append("projects", JSON.stringify(batchProjects.map(p => p.id)));
      form.append("clients", JSON.stringify(batchClients.map(c => c.id)));
      form.append("users", JSON.stringify(batchUsers.map(u => u.id)));

      await axios.post("/api/files/batch-upload", form, { headers: { "Content-Type": "multipart/form-data" } });

      setBatchFiles([]);
      setBatchTags([]); setBatchTeams([]); setBatchProjects([]); setBatchClients([]); setBatchUsers([]);
      setReloadFlag(f => !f);
      alert("Caricamento completato!");
    } catch (e) {
      alert("Errore nel caricamento batch: " + (e.response?.data?.error || e.message));
    } finally {
      setUploading(false);
    }
  };

  // Breadcrumb
  const getBreadcrumb = () => {
    if (!selectedNode) return <span style={{ color: "#999" }}>Nessuna cartella selezionata</span>;
    let path = selectedNode.path || selectedNode.name;
    return <span>{path}</span>;
  };

  // È una cartella?
  const isFolder = selectedNode && selectedNode.files !== undefined;

  // --- UI ---
  return (
    <div style={{ display: "flex", height: "calc(100vh - 48px)" }}>
      {/* TreeView */}
      <div style={{ width: 270, borderRight: "1.5px solid #eaeaea", background: "#fafaff", minHeight: "100%" }}>
        <FilesTreeView
          onSelect={setSelectedNode}
          selectedId={selectedNode?.id}
          reloadFlag={reloadFlag}
        />
      </div>

      {/* Destra: batch e tabella */}
      <div style={{ flex: 1, padding: 22, overflow: "auto" }}>
        <div style={{ marginBottom: 12, fontSize: 16, color: "#333" }}>
          <b>Percorso corrente: </b>{getBreadcrumb()}
        </div>

        {/* DROPZONE E UPLOAD MULTIPLO */}
        {isFolder && (
          <div
            style={{
              border: "2px dashed #90caf9", borderRadius: 12, padding: 32, marginBottom: 22,
              background: "#f9fbff", textAlign: "center", transition: "0.2s"
            }}
            onDrop={e => { e.preventDefault(); handleFilesSelected(e); }}
            onDragOver={e => e.preventDefault()}
          >
            <input type="file" multiple style={{ display: "none" }} id="batchUpload" onChange={handleFilesSelected} />
            <label htmlFor="batchUpload" style={{ cursor: "pointer", color: "#1976d2" }}>
              <b>Trascina qui i file</b> o <u>clicca per selezionare</u>
            </label>
            <div style={{ marginTop: 8, color: "#666", fontSize: 13 }}>
              I file verranno caricati nella cartella: <b>{selectedNode?.name || "-"}</b>
            </div>
            {/* Preview file selezionati */}
            {batchFiles.length > 0 && (
              <div style={{ textAlign: "left", margin: "18px auto", maxWidth: 600 }}>
                <b style={{ fontSize: 15 }}>File selezionati:</b>
                <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
                  {batchFiles.map((f, i) =>
                    <li key={i} style={{ marginBottom: 2, display: "flex", alignItems: "center", gap: 7 }}>
                      <span style={{ color: "#999", fontSize: 16 }}>
                        {/\.(pdf)$/i.test(f.name) ? "📄" : /\.(jpe?g|png|gif)$/i.test(f.name) ? "🖼️" : "📎"}
                      </span>
                      {f.name} <span style={{ color: "#888", fontSize: 12 }}>({Math.round(f.size / 1024)} KB)</span>
                      <button type="button" style={{
                        background: "none", border: "none", color: "#e23", fontWeight: "bold", marginLeft: 5, cursor: "pointer"
                      }} onClick={() => removeBatchFile(i)} title="Rimuovi file">×</button>
                    </li>
                  )}
                </ul>
              </div>
            )}
            {/* BATCH SELEZIONE: TAG/TEAM/PROGETTI/CLIENTI/UTENTI */}
            {batchFiles.length > 0 && (
              <div style={{
                background: "#f6faff", borderRadius: 10, boxShadow: "0 1px 8px #eaeaea",
                padding: 20, marginBottom: 8, maxWidth: 800, margin: "16px auto"
              }}>
                <BatchSelector
                  label="Tag"
                  items={tags}
                  selected={batchTags}
                  setSelected={setBatchTags}
                  color="green"
                  badgeType="name"
                />
                <BatchSelector
                  label="Team"
                  items={teams}
                  selected={batchTeams}
                  setSelected={setBatchTeams}
                  color="blue"
                  badgeType="name"
                />
                <BatchSelector
                  label="Progetti"
                  items={projects}
                  selected={batchProjects}
                  setSelected={setBatchProjects}
                  color="yellow"
                  badgeType="title"
                />
                <BatchSelector
                  label="Aziende"
                  items={clients}
                  selected={batchClients}
                  setSelected={setBatchClients}
                  color="red"
                  badgeType="company"
                />
                <BatchSelector
                  label="Utenti"
                  items={users}
                  selected={batchUsers}
                  setSelected={setBatchUsers}
                  color="violet"
                  badgeType="fullname"
                />
                <div style={{ textAlign: "right", marginTop: 10 }}>
                  <button
                    className="px-7 py-2 rounded-xl bg-blue-600 text-white font-semibold shadow hover:bg-blue-700 transition"
                    disabled={uploading}
                    onClick={handleBatchUpload}
                  >
                    {uploading ? "Caricamento..." : "Carica tutti i file"}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TABELLA FILE DELLA CARTELLA */}
        {/* Puoi qui integrare FileTable o una tabella semplice */}
        {isFolder && (
          <div>
            <FileTable
              files={selectedNode.files}
              // altre props come onView, onEdit, onDelete... da aggiungere secondo la tua logica
            />
          </div>
        )}
      </div>
    </div>
  );
}

// --- COMPONENTE FILE TABLE BASE ---
// Puoi personalizzare colonne, badge, azioni secondo la tua logica
function FileTable({ files = [] }) {
  if (!files.length) return <div style={{ color: "#888", marginTop: 30 }}>Nessun file trovato.</div>;
  return (
    <table style={{
      width: "100%", marginTop: 18, background: "#fff", borderRadius: 10,
      boxShadow: "0 1px 6px #eee", borderCollapse: "collapse"
    }}>
      <thead>
        <tr style={{ background: "#f2f4fb", fontSize: 15 }}>
          <th style={{ padding: "8px 14px", textAlign: "left" }}>Nome</th>
          <th style={{ padding: "8px 14px" }}>Azioni</th>
        </tr>
      </thead>
      <tbody>
        {files.map(file => (
          <tr key={file.id} style={{ borderBottom: "1px solid #f0f0f0" }}>
            <td style={{ padding: "9px 14px", fontSize: 16 }}>{file.name}</td>
            <td style={{ padding: "9px 14px" }}>
              {/* Puoi aggiungere bottoni/icone azioni */}
              <span style={{ color: "#1566a7", marginRight: 14, cursor: "pointer" }} title="Dettagli">👁️</span>
              <span style={{ color: "#e26929", cursor: "pointer" }} title="Elimina">🗑️</span>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
