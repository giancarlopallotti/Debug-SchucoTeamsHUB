// Percorso: /pages/files.js
// Scopo: Dashboard file manager con upload drag&drop + badge assegnazione
// Autore: ChatGPT, su specifiche NucleusStudio
// Ultima modifica: 09/06/2025

import { useState, useEffect } from "react";
import FilesTreeView from "../components/FilesTreeView";
import UploadForm from "../components/UploadForm";
import axios from "axios";

export default function FilesPage() {
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [tags, setTags] = useState([]);
  const [teams, setTeams] = useState([]);
  const [projects, setProjects] = useState([]);
  const [clients, setClients] = useState([]);
  const [users, setUsers] = useState([]);
  const [reloadFlag, setReloadFlag] = useState(false);

  // Carica dati disponibili per badge all’avvio
  useEffect(() => {
    axios.get("/api/tags").then(res => setTags(res.data || []));
    axios.get("/api/teams").then(res => setTeams(res.data || []));
    axios.get("/api/projects").then(res => setProjects(res.data || []));
    axios.get("/api/clients").then(res => setClients(res.data || []));
    axios.get("/api/users").then(res => setUsers(res.data || []));
  }, []);

  // Forza refresh tree
  const reloadTree = () => setReloadFlag(f => !f);

  // Mostra path (puoi customizzare con breadcrumb se vuoi)
  const folderPath = selectedFolder?.path || selectedFolder?.name || "";

  return (
    <div style={{ display: "flex", height: "calc(100vh - 50px)" }}>
      {/* SINISTRA: TreeView */}
      <div style={{ width: 270, borderRight: "1.5px solid #eaeaea", background: "#fafaff" }}>
        <FilesTreeView
          onSelect={node => {
            // Seleziona solo cartelle per upload (non file)
            if (node && node.files) setSelectedFolder(node);
            else if (node && node.folder_id === undefined) setSelectedFolder(node);
            // NB: Se vuoi mostrare i dettagli file, qui puoi salvare il file selezionato in altro stato
          }}
          selectedId={selectedFolder?.id}
          reloadFlag={reloadFlag}
        />
      </div>

      {/* DESTRA: Upload + contenuto cartella */}
      <div style={{ flex: 1, padding: 18, overflow: "auto" }}>
        {/* Breadcrumb / Path */}
        <div style={{ marginBottom: 14, fontSize: 16, color: "#333" }}>
          <b>Percorso corrente:</b>{" "}
          {selectedFolder
            ? (folderPath || <span style={{ color: "#999" }}>Nessuna cartella selezionata</span>)
            : <span style={{ color: "#999" }}>Nessuna cartella selezionata</span>
          }
        </div>

        {/* UploadForm: visibile solo se selezioni una cartella */}
        {selectedFolder && (
          <UploadForm
            folder={selectedFolder}
            tags={tags}
            teams={teams}
            projects={projects}
            clients={clients}
            users={users}
            onUploaded={reloadTree}
          />
        )}

        {/* TODO: qui puoi aggiungere tabella file della cartella o dettaglio file selezionato */}
      </div>
    </div>
  );
}
