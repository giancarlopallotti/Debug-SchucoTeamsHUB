// Percorso: /pages/api/files/index.js
// Scopo: API gestione file con supporto campo note
// Autore: ChatGPT
// Ultima modifica: 25/05/2025

import db from "../../../db/db";
import formidable from "formidable";
import fs from "fs";
import path from "path";

export const config = {
  api: {
    bodyParser: false,
  },
};

const uploadDir = path.resolve(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

function parseTagsFromRequest(req) {
  try {
    return JSON.parse(req.fields.tag_ids || "[]");
  } catch {
    return [];
  }
}

export default async function handler(req, res) {
  if (req.method === "GET") {
    // Lista file
    const files = db.prepare(`
      SELECT f.*, u.name AS uploaded_by,
        GROUP_CONCAT(t.name, ', ') AS tags
      FROM files f
      LEFT JOIN users u ON f.user_id = u.id
      LEFT JOIN file_tags ft ON ft.file_id = f.id
      LEFT JOIN tags t ON ft.tag_id = t.id
      GROUP BY f.id
      ORDER BY f.uploaded_at DESC
    `).all();

    // Ritorna tag come array invece di stringa
    files.forEach(f => {
      f.tags = (f.tags || "").split(", ").filter(Boolean);
    });

    return res.status(200).json(files);
  }

  if (req.method === "POST") {
    const form = new formidable.IncomingForm({ multiples: true, uploadDir, keepExtensions: true });

    form.parse(req, async (err, fields, filesObj) => {
      if (err) return res.status(500).json({ error: "Errore upload" });

      // Estrai tutti i dati dal form
      const { team_id, project_id, subfolder, note = "" } = fields;
      const tagIds = parseTagsFromRequest({ fields });
      const user_id = 1; // Sostituisci con session user id!

      let fileList = filesObj.files ? (Array.isArray(filesObj.files) ? filesObj.files : [filesObj.files]) : [];
      if (!team_id || !project_id || !fileList.length) {
        return res.status(400).json({ error: "Dati insufficienti" });
      }

      const now = new Date().toISOString();
      let inserted = [];

      for (const file of fileList) {
        const fileName = file.originalFilename || file.newFilename;
        const filePath = file.filepath.replace(process.cwd(), "");
        const fileSize = file.size || 0;
        const fileType = file.mimetype || path.extname(fileName).slice(1);

        // Salva metadati nel db con campo note
        const stmt = db.prepare(`
          INSERT INTO files (name, path, size, type, team_id, project_id, subfolder, user_id, uploaded_at, note)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        const result = stmt.run(
          fileName,
          filePath,
          fileSize,
          fileType,
          team_id,
          project_id,
          subfolder || "",
          user_id,
          now,
          note
        );
        const file_id = result.lastInsertRowid;

        // Associa tag
        if (tagIds.length) {
          const tagStmt = db.prepare("INSERT INTO file_tags (file_id, tag_id) VALUES (?, ?)");
          tagIds.forEach(tid => tagStmt.run(file_id, tid));
        }

        inserted.push({
          id: file_id,
          name: fileName,
          size: fileSize,
          type: fileType,
          tags: tagIds,
          note
        });
      }
      res.status(201).json({ success: true, inserted });
    });
    return;
  }

  res.setHeader("Allow", ["GET", "POST"]);
  res.status(405).end("Metodo non permesso");
}
