// Percorso: /pages/files.js
// Scopo: Gestione file e allegati – orchestrazione con componenti separati
// Autore: ChatGPT – Refactor 25/05/2025

import { useEffect, useState } from "react";
import FileUploadForm from "../pages/components/FileUploadForm";
import FileTable from "../pages/components/FileTable";

export default function FilesPage() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [teams, setTeams] = useState([]);
  const [projects, setProjects] = useState([]);
  const [tags, setTags] = useState([]);
  const [selectedTags, setSelectedTags] = useState([]);
  const [teamId, setTeamId] = useState("");
  const [projectId, setProjectId] = useState("");
  const [subfolder, setSubfolder] = useState("");
  const [uploadFiles, setUploadFiles] = useState([]);
  const [note, setNote] = useState("");
  const [isPublic, setIsPublic] = useState(false);

  useEffect(() => { fetchFiles(); }, []);
  useEffect(() => { fetchTeams(); }, []);
  useEffect(() => { fetchProjects(); }, []);
  useEffect(() => { fetchTags(); }, []);

  const fetchFiles = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/files");
      if (!res.ok) throw new Error("Errore durante il recupero dei file");
      const data = await res.json();
      setFiles(data);
    } catch (err) {
      setError(err.message || "Errore imprevisto");
    } finally {
      setLoading(false);
    }
  };

  const fetchTeams = async () => {
    try {
      const res = await fetch("/api/teams");
      if (res.ok) {
        const data = await res.json();
        setTeams(data);
      }
    } catch {}
  };

  const fetchProjects = async () => {
    try {
      const res = await fetch("/api/projects");
      if (res.ok) {
        const data = await res.json();
        setProjects(data);
      }
    } catch {}
  };

  const fetchTags = async () => {
    try {
      const res = await fetch("/api/tags");
      if (res.ok) {
        const data = await res.json();
        setTags(data);
      }
    } catch {}
  };

  const handleCreateTag = async (tagName) => {
    try {
      const res = await fetch("/api/tags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: tagName }),
      });
      if (res.ok) {
        const newTag = await res.json();
        setTags(prev => [...prev, newTag]);
        setSelectedTags(prev => [...prev, newTag]);
      }
    } catch {}
  };

  const handleTagsChange = (newTags) => {
    const uniqueTags = Array.from(new Map(newTags.map(t => [t.id, t])).values());
    setSelectedTags(uniqueTags);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    setUploading(true);
    setUploadError("");
    try {
      if (!teamId || !projectId || uploadFiles.length === 0) {
        setUploadError("Seleziona team, progetto e almeno un file.");
        setUploading(false);
        return;
      }
      const formData = new FormData();
      formData.append("team_id", teamId);
      formData.append("project_id", projectId);
      formData.append("subfolder", subfolder);
      formData.append("tag_ids", JSON.stringify(selectedTags.map(t => t.id)));
      formData.append("note", note);
      formData.append("is_public", isPublic ? 1 : 0);
      uploadFiles.forEach(file => formData.append("files", file));

      const res = await fetch("/api/files", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) throw new Error("Errore nell'upload");
      await fetchFiles();
      setUploadFiles([]);
      setSelectedTags([]);
      setSubfolder("");
      setNote("");
      setIsPublic(false);
    } catch (err) {
      setUploadError(err.message || "Errore durante l'upload");
    } finally {
      setUploading(false);
    }
  };

  // Filtra files per ricerca testuale su nome/tag/note
  const filteredFiles = files.filter(
    f =>
      !search ||
      f.name?.toLowerCase().includes(search.toLowerCase()) ||
      (Array.isArray(f.tags)
        ? f.tags.join(" ").toLowerCase().includes(search.toLowerCase())
        : (f.tags || "").toLowerCase().includes(search.toLowerCase())) ||
      (f.note || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex gap-3">
      {/* Sidebar Explorer */}
      <aside className="hidden md:block min-w-[170px] max-w-[220px] bg-blue-50 rounded-xl shadow p-2 h-fit mt-2">
        <div className="font-bold mb-3 text-blue-900">Filtri Rapidi</div>
        <ul className="space-y-1 text-xs">
          <li><button className="hover:underline text-blue-700">Tutti i file</button></li>
          <li><button className="hover:underline text-blue-700">File pubblici</button></li>
          <li><button className="hover:underline text-blue-700">I miei file</button></li>
        </ul>
        <div className="border-t mt-3 pt-3 text-xs text-gray-400">Sidebar Explorer (in sviluppo)</div>
      </aside>
      <div className="flex-1">
        <main className="p-4 md:p-6">
          <h1 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-blue-900">Gestione File e Allegati</h1>

          <FileUploadForm
            teams={teams}
            projects={projects}
            tags={tags}
            selectedTags={selectedTags}
            setSelectedTags={setSelectedTags}
            teamId={teamId}
            setTeamId={setTeamId}
            projectId={projectId}
            setProjectId={setProjectId}
            subfolder={subfolder}
            setSubfolder={setSubfolder}
            note={note}
            setNote={setNote}
            isPublic={isPublic}
            setIsPublic={setIsPublic}
            uploadFiles={uploadFiles}
            setUploadFiles={setUploadFiles}
            uploading={uploading}
            uploadError={uploadError}
            handleUpload={handleUpload}
            handleTagsChange={handleTagsChange}
            handleCreateTag={handleCreateTag}
          />

          <div className="mb-2 flex flex-col md:flex-row gap-2 md:gap-4">
            <input
              type="text"
              placeholder="Cerca per nome o tag..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="border px-2 py-1 rounded w-full md:w-64 text-xs"
              style={{ fontSize: "12px", height: "26px" }}
            />
            <button
              onClick={fetchFiles}
              className="px-3 py-1 bg-blue-700 text-white rounded shadow hover:bg-blue-800 text-xs"
              style={{ fontSize: "12px", height: "28px", minWidth: "90px" }}
            >
              Aggiorna lista
            </button>
          </div>

          <FileTable files={filteredFiles} loading={loading} error={error} />
        </main>
      </div>
    </div>
  );
}
