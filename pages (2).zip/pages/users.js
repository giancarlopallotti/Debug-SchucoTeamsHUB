// Percorso: /pages/users.js
// Scopo: Layout utenti stile Microsoft Windows Fluent - colorato e professionale
// Autore: ChatGPT
// Ultima modifica: 25/05/2025
// Note: Migliorie grafiche, badge ruoli, barra filtri sticky

import { useEffect, useState } from "react";
import { FaUserPlus, FaSearch, FaUsers, FaSyncAlt } from "react-icons/fa";
import UserModal from "./components/UserModal"; // Assicurati sia corretto il percorso

const roleColors = {
  Admin: "bg-blue-600 text-white",
  Supervisor: "bg-green-500 text-white",
  Operatore: "bg-purple-500 text-white",
  Cliente: "bg-gray-400 text-black"
};

export default function UsersPage() {
  // State & hooks...
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [modalUser, setModalUser] = useState(null);

  useEffect(() => {
    fetch("/api/users")
      .then(res => res.json())
      .then(data => setUsers(Array.isArray(data) ? data : []));
  }, []);

  // Filtraggio semplice per esempio
  const filteredUsers = users.filter(u =>
    (!roleFilter || u.role === roleFilter) &&
    (!search || u.name.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-[#f3f6fd] px-0 md:px-8 py-4">
      {/* Barra filtri */}
      <div className="sticky top-0 z-20 bg-white/80 backdrop-blur-md flex flex-col md:flex-row items-center justify-between shadow-md rounded-2xl p-4 mb-8 border border-blue-100">
        <div className="flex items-center gap-2 w-full md:w-auto mb-2 md:mb-0">
          <FaUsers className="text-blue-500 text-2xl mr-2" />
          <input
            type="text"
            placeholder="Cerca utente..."
            className="rounded-xl px-4 py-2 border border-blue-200 bg-white shadow focus:outline-blue-400 transition"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <select
            className="rounded-xl px-3 py-2 ml-2 border border-blue-200 bg-white text-blue-700"
            value={roleFilter}
            onChange={e => setRoleFilter(e.target.value)}
          >
            <option value="">Tutti i ruoli</option>
            <option value="Admin">Admin</option>
            <option value="Supervisor">Supervisor</option>
            <option value="Operatore">Operatore</option>
            <option value="Cliente">Cliente</option>
          </select>
          <button
            className="ml-2 rounded-xl bg-blue-600 text-white px-4 py-2 font-semibold shadow hover:bg-blue-700 transition"
            onClick={() => setModalUser({})}
          >
            <FaUserPlus className="inline mr-2" /> Nuovo utente
          </button>
        </div>
        <button
          className="rounded-xl bg-blue-100 text-blue-700 px-4 py-2 font-semibold hover:bg-blue-200 transition flex items-center"
          onClick={() => window.location.reload()}
        >
          <FaSyncAlt className="mr-2" /> Aggiorna elenco
        </button>
      </div>

      {/* Lista utenti */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map(user => (
          <div
            key={user.id}
            className="rounded-2xl bg-white hover:shadow-2xl shadow-md p-5 flex flex-col gap-2 border border-blue-100 transition-all duration-200 relative"
            style={{ minHeight: 170 }}
          >
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-blue-100 shadow-sm bg-blue-50 flex items-center justify-center">
                <img
                  src={user.avatar || "/default-avatar.png"}
                  alt={user.name}
                  className="object-cover w-full h-full"
                />
              </div>
              <div>
                <div className="font-bold text-lg text-blue-800">{user.name}</div>
                <div className="text-gray-500 text-sm">{user.email}</div>
                <div className="mt-1 flex flex-wrap gap-2">
                  {(Array.isArray(user.roles) ? user.roles : [user.role]).map(role => (
                    <span
                      key={role}
                      className={`px-3 py-1 rounded-2xl text-xs font-semibold shadow ${roleColors[role] || "bg-gray-200 text-gray-800"}`}
                    >
                      {role}
                    </span>
                  ))}
                  {user.status === "inactive" && (
                    <span className="px-3 py-1 rounded-2xl text-xs bg-red-100 text-red-700 font-semibold">Non attivo</span>
                  )}
                </div>
              </div>
            </div>
            <div className="mt-auto flex gap-2">
              <button
                className="px-4 py-2 rounded-xl bg-blue-50 text-blue-800 font-semibold shadow hover:bg-blue-200 transition"
                onClick={() => setModalUser(user)}
              >
                Modifica
              </button>
              <button
                className="px-4 py-2 rounded-xl bg-red-100 text-red-600 font-semibold shadow hover:bg-red-200 transition"
                // onClick={() => handleDeleteUser(user.id)}
              >
                Elimina
              </button>
            </div>
            {/* badge laterale */}
            <span className="absolute top-3 right-3 text-xs bg-blue-200 text-blue-700 rounded-full px-3 py-1 shadow">
              ID: {user.id}
            </span>
          </div>
        ))}
      </div>

      {/* Modal gestione utente */}
      {modalUser && (
        <UserModal user={modalUser} onClose={() => setModalUser(null)} />
      )}
    </div>
  );
}
