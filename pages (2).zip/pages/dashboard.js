// Percorso: /pages/dashboard.js
// Scopo: Dashboard avanzata con layout e visibilità widget persistenti (SQL), Dark Mode, Widget notifiche interattivo (modale)
// Autore: ChatGPT
// Ultima modifica: 25/05/2025

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import GridLayout from "react-grid-layout";
import "react-grid-layout/css/styles.css";

// --- Widget Messaggi (robusto su errore API) ---
function WidgetMessaggi({ limit = 5, darkMode }) {
  const [msgs, setMsgs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/messages?box=inbox`)
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) {
          setMsgs(data.slice(0, limit));
        } else {
          setMsgs([]);
        }
      })
      .finally(() => setLoading(false));
  }, [limit]);

  return (
    <div className={`
      rounded-2xl shadow p-4 min-h-[150px] flex flex-col
      ${darkMode ? "bg-gray-800 text-gray-100" : "bg-white"}
    `}>
      <div className="flex items-center justify-between mb-2">
        <span className={`text-lg font-bold ${darkMode ? "text-blue-200" : "text-blue-800"}`}>📧 Messaggi</span>
        <Link href="/messages" className={`text-xs ${darkMode ? "text-blue-300" : "text-blue-700"} hover:underline`}>Vedi tutti</Link>
      </div>
      {loading ? (
        <div className="text-sm text-gray-400">Caricamento...</div>
      ) : msgs.length === 0 ? (
        <div className="text-sm text-gray-400">Nessun messaggio</div>
      ) : (
        <ul className="divide-y text-sm">
          {msgs.map(m => (
            <li key={m.id} className={"py-2 flex items-center gap-2 " + (m.read ? "" : (darkMode ? "font-bold bg-blue-900/30" : "font-bold bg-blue-50")) }>
              <span className="flex-1 cursor-pointer truncate" title={m.subject}>{m.subject}</span>
              {!m.read && <span className={`inline-block w-2 h-2 ${darkMode ? "bg-blue-300" : "bg-blue-600"} rounded-full mr-2`}></span>}
              <span className="text-xs text-gray-400">{m.created_at?.split('T')[0]}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// --- Definizione e mapping widget ---
const defaultWidgets = {
  notifications: {
    label: "Notifiche recenti",
    icon: "🔔",
    color: "text-orange-700"
  },
  users: {
    label: "Utenti registrati",
    icon: "👥",
    color: "text-blue-800"
  },
  files: {
    label: "File caricati",
    icon: "📂",
    color: "text-blue-800"
  },
  downloads: {
    label: "Download totali",
    icon: "⬇️",
    color: "text-blue-800"
  },
  note: {
    label: "Note personali",
    icon: "📝",
    color: "text-yellow-700"
  },
  messages: {
    label: "Messaggi ricevuti",
    icon: "📧",
    color: "text-blue-800"
  }
};

const defaultActiveWidgets = {
  notifications: true,
  users: true,
  files: true,
  downloads: false,
  note: false,
  messages: true
};

const initialLayout = [
  { i: "notifications", x: 0, y: 0, w: 1, h: 2, minW: 1, minH: 2 },
  { i: "users",         x: 1, y: 0, w: 1, h: 2, minW: 1, minH: 2 },
  { i: "files",         x: 2, y: 0, w: 1, h: 2, minW: 1, minH: 2 },
  { i: "downloads",     x: 0, y: 2, w: 1, h: 2, minW: 1, minH: 2 },
  { i: "note",          x: 1, y: 2, w: 2, h: 2, minW: 1, minH: 2 },
  { i: "messages",      x: 2, y: 2, w: 1, h: 2, minW: 1, minH: 2 }
];

export default function Dashboard() {
  const [widgets, setWidgets] = useState(defaultWidgets);
  const [activeWidgets, setActiveWidgets] = useState(defaultActiveWidgets);
  const [user, setUser] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showSelector, setShowSelector] = useState(false);
  const [layout, setLayout] = useState(initialLayout);
  const [layoutLoaded, setLayoutLoaded] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [modalNotifica, setModalNotifica] = useState(null); // Per popup dettaglio

  // Recupera layout + stato widget attivi + dark mode da backend all'avvio
  useEffect(() => {
    fetch('/api/user/widgets', { method: 'GET', credentials: 'include' })
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        if (data && Array.isArray(data.layout)) setLayout(data.layout);
        if (data && typeof data.activeWidgets === "object") setActiveWidgets(data.activeWidgets);
        if (typeof data?.darkMode === "boolean") setDarkMode(data.darkMode);
        setLayoutLoaded(true);
      })
      .catch(() => setLayoutLoaded(true));
  }, []);

  // Salva layout, widget attivi e darkmode ogni volta che cambia
  const handleLayoutChange = useCallback((newLayout) => {
    setLayout(newLayout);
    if (layoutLoaded) {
      fetch('/api/user/widgets', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ layout: newLayout, activeWidgets, darkMode })
      });
    }
  }, [layoutLoaded, activeWidgets, darkMode]);

  const handleActiveWidgetsChange = (next) => {
    setActiveWidgets(next);
    if (layoutLoaded) {
      fetch('/api/user/widgets', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ layout, activeWidgets: next, darkMode })
      });
    }
  };

  const handleToggleDarkMode = () => {
    setDarkMode(dm => {
      const next = !dm;
      if (layoutLoaded) {
        fetch('/api/user/widgets', {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ layout, activeWidgets, darkMode: next })
        });
      }
      return next;
    });
  };

  useEffect(() => {
    fetch('/api/auth/me', { credentials: "include" })
      .then(res => res.ok ? res.json() : null)
      .then(userData => {
        setUser(userData);
        if (userData?.id) {
          fetch(`/api/notifications?user_id=${userData.id}`)
            .then(res => res.json())
            .then(data => {
              setNotifications(Array.isArray(data) ? data.filter(n => !n.read).slice(0, 3) : []);
              setLoading(false);
            });
        } else {
          setLoading(false);
        }
      });
  }, []);

  // Azione "segna come letto"
  const markNotificationRead = (id) => {
    fetch('/api/notifications/read', {
      method: 'POST',
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ id })
    }).then(() => {
      setModalNotifica(null);
      // Aggiorna lista notifiche dopo lettura
      if (user?.id) {
        fetch(`/api/notifications?user_id=${user.id}`)
          .then(res => res.json())
          .then(data => setNotifications(Array.isArray(data) ? data.filter(n => !n.read).slice(0, 3) : []));
      }
    });
  };

  // Rende la dashboard drag & drop e responsive
  const filteredWidgets = Object.entries(activeWidgets)
    .filter(([_, v]) => v)
    .map(([key]) => key);

  // Render widget per tipo
  const renderWidget = (key) => {
    switch (key) {
      case "notifications":
        return (
          <div key={key} className={`
            rounded shadow p-4 flex items-center h-full
            ${darkMode ? "bg-gray-800 text-orange-200" : "bg-white"}
          `}>
            <div className="mr-4 text-3xl">{widgets[key].icon}</div>
            <div className="flex-1">
              <div className="flex items-center mb-2">
                <span className={`font-semibold ${darkMode ? "text-orange-200" : widgets[key].color}`}>{widgets[key].label}</span>
                {notifications.length > 0 && (
                  <span className="ml-2 bg-red-500 text-white text-xs font-bold rounded-full px-2 py-0.5 animate-pulse">Nuovo</span>
                )}
              </div>
              {loading ? (
                <div className="text-gray-400 text-xs">Caricamento...</div>
              ) : notifications.length === 0 ? (
                <div className="text-gray-400 text-xs">Nessuna nuova notifica</div>
              ) : (
                <ul className="space-y-1 text-xs">
                  {notifications.map(n => (
                    <li
                      key={n.id}
                      className="border-b last:border-b-0 pb-1 text-blue-900 font-medium flex items-center cursor-pointer hover:bg-blue-50"
                      onClick={() => setModalNotifica(n)}
                      title="Dettagli notifica"
                    >
                      {n.message.length > 60 ? n.message.substring(0, 58) + "…" : n.message}
                      <span className="ml-3 text-gray-400 font-normal">
                        {new Date(n.created_at).toLocaleString()}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
              <div className="mt-2">
                <Link href="/notifications" className={`text-xs underline hover:text-blue-900 ${darkMode ? "text-blue-300" : "text-blue-600"}`}>
                  Visualizza tutte le notifiche
                </Link>
              </div>
            </div>
          </div>
        );
      case "users":
        return (
          <div key={key} className={`rounded shadow p-4 flex items-center h-full ${darkMode ? "bg-gray-800 text-blue-200" : "bg-white"}`}>
            <div className="mr-4 text-3xl">{widgets[key].icon}</div>
            <div>
              <div className={`font-semibold ${darkMode ? "text-blue-200" : widgets[key].color}`}>{widgets[key].label}</div>
              <div className="text-2xl font-bold mt-2">15</div>
              <div className="text-xs text-gray-400 mt-1">Attualmente registrati</div>
            </div>
          </div>
        );
      case "files":
        return (
          <div key={key} className={`rounded shadow p-4 flex items-center h-full ${darkMode ? "bg-gray-800 text-blue-200" : "bg-white"}`}>
            <div className="mr-4 text-3xl">{widgets[key].icon}</div>
            <div>
              <div className={`font-semibold ${darkMode ? "text-blue-200" : widgets[key].color}`}>{widgets[key].label}</div>
              <div className="text-2xl font-bold mt-2">27</div>
              <div className="text-xs text-gray-400 mt-1">Caricati in totale</div>
            </div>
          </div>
        );
      case "downloads":
        return (
          <div key={key} className={`rounded shadow p-4 flex items-center h-full ${darkMode ? "bg-gray-800 text-blue-200" : "bg-white"}`}>
            <div className="mr-4 text-3xl">{widgets[key].icon}</div>
            <div>
              <div className={`font-semibold ${darkMode ? "text-blue-200" : widgets[key].color}`}>{widgets[key].label}</div>
              <div className="text-2xl font-bold mt-2">52</div>
              <div className="text-xs text-gray-400 mt-1">Download totali</div>
            </div>
          </div>
        );
      case "note":
        return (
          <div key={key} className={`border-l-8 border-yellow-500 rounded p-4 h-full ${darkMode ? "bg-yellow-900 text-yellow-100" : "bg-yellow-100"}`}>
            <h2 className="text-md font-semibold text-yellow-800 mb-2">📝 Note rapide</h2>
            <textarea
              rows="4"
              className="w-full p-2 border rounded bg-yellow-50"
              placeholder="Scrivi una nota personale qui..."
              style={darkMode ? { background: "#654", color: "#ffe" } : {}}
            />
          </div>
        );
      case "messages":
        return <WidgetMessaggi key={key} limit={5} darkMode={darkMode} />;
      default:
        return null;
    }
  };

  return (
    <div className={darkMode ? "bg-gray-900 min-h-screen" : "bg-gray-100 min-h-screen"} style={{ transition: "background 0.2s" }}>
      <main className="flex-1 p-6 space-y-6" style={{ color: darkMode ? "#e4e9f7" : "#213b63" }}>
        {/* HEADER su unica riga, responsive */}
        <div className="flex flex-col md:flex-row md:items-center md:gap-6 mb-4">
          <div className="flex items-center gap-3">
            <h1 className={`text-2xl font-bold flex-shrink-0 ${darkMode ? "text-blue-200" : "text-blue-900"}`}>Dashboard</h1>
            <button
              className={"ml-4 px-2 py-1 rounded text-xs font-semibold " + (darkMode ? "bg-gray-900 text-white border border-gray-700" : "bg-gray-200 text-gray-700 border border-gray-300")}
              onClick={handleToggleDarkMode}
              title="Cambia tema"
              style={{ marginLeft: 16, transition: "all 0.2s" }}
            >
              {darkMode ? "🌙 Dark" : "☀️ Light"}
            </button>
          </div>
          <div className="flex flex-col md:flex-row md:items-center md:gap-4 w-full">
            <span className="text-sm text-gray-400 md:border-l md:pl-4 md:ml-4">Benvenuto nella tua area personale</span>
            {user && (
              <span className={
                "text-sm font-medium md:ml-4 " +
                (darkMode ? "text-gray-300" : "text-gray-800")
              }>
                Nome: {user.name} &nbsp; Cognome: {user.surname} &nbsp; • Ruolo:{" "}
                <span style={{
                  color: darkMode ? "#46e487" : "#0b9639",
                  fontWeight: 600
                }}>{user.role}</span>
              </span>
            )}
          </div>
          <button
            onClick={() => setShowSelector(s => !s)}
            className={`ml-auto mt-2 md:mt-0 text-xs px-4 py-2 rounded shadow border ${darkMode ? "bg-gray-800 text-blue-200 border-gray-700 hover:bg-gray-700" : "bg-blue-100 text-blue-700 border-blue-200 hover:bg-blue-200"}`}
          >
            {showSelector ? "Nascondi widget" : "Scegli widget"}
          </button>
        </div>

        {/* Menu a tendina per selezione widget */}
        {showSelector && (
          <div className={`shadow border rounded mb-6 p-4 w-full max-w-xl ${darkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"}`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {Object.entries(widgets).map(([key, w]) => (
                <label key={key} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={activeWidgets[key]}
                    onChange={e => handleActiveWidgetsChange({ ...activeWidgets, [key]: e.target.checked })}
                  />
                  <span className="text-sm">{w.icon} {w.label}</span>
                </label>
              ))}
            </div>
          </div>
        )}

        {/* Griglia drag & drop dinamica e responsive */}
        <GridLayout
          className="layout"
          layout={layout.filter(l => filteredWidgets.includes(l.i))}
          cols={3}
          rowHeight={90}
          width={1200}
          onLayoutChange={handleLayoutChange}
          isResizable={true}
          isDraggable={true}
          draggableHandle=".bg-white, .bg-yellow-100, .bg-gray-800, .bg-yellow-900"
          compactType="vertical"
          style={{ minHeight: 350 }}
          margin={[16, 16]}
          useCSSTransforms={true}
          autoSize={true}
        >
          {filteredWidgets.map((key) => (
            <div key={key} data-grid={layout.find(l => l.i === key) || { i: key, x: 0, y: 0, w: 1, h: 2 }}>
              {renderWidget(key)}
            </div>
          ))}
        </GridLayout>

        {/* --- Modale Dettaglio Notifica --- */}
        {modalNotifica && (
          <div
            style={{
              position: "fixed", left: 0, top: 0, width: "100vw", height: "100vh", zIndex: 10010,
              background: "rgba(20,32,60,0.20)", display: "flex", alignItems: "center", justifyContent: "center"
            }}
            onClick={() => setModalNotifica(null)}
          >
            <div
              className={`rounded-2xl shadow-xl p-6 max-w-md w-full relative animate-pop ${darkMode ? "bg-gray-900 text-gray-100" : "bg-white"}`}
              style={{
                minWidth: 320, minHeight: 180,
                animation: "popIn 0.25s cubic-bezier(.41,1.4,.67,.97)",
                boxShadow: "0 8px 36px 0 #213b6355"
              }}
              onClick={e => e.stopPropagation()}
            >
              <div className="mb-2 flex items-center gap-2">
                <span className="text-2xl">🔔</span>
                <span className="font-bold text-blue-900">Dettaglio notifica</span>
              </div>
              <div className="mb-3">
                <div className="text-base text-blue-900 font-semibold mb-2">{modalNotifica.title || "Messaggio"}</div>
                <div className="text-gray-700 mb-3" style={{ whiteSpace: "pre-line" }}>{modalNotifica.message}</div>
                <div className="text-xs text-gray-500 mb-2">
                  Ricevuta il {new Date(modalNotifica.created_at).toLocaleString()}
                </div>
              </div>
              <div className="flex gap-3 justify-end mt-2">
                <button
                  className="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 text-xs"
                  onClick={() => markNotificationRead(modalNotifica.id)}
                >Segna come letto</button>
                {modalNotifica.link && (
                  <a
                    className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-xs"
                    href={modalNotifica.link} target="_blank" rel="noopener noreferrer"
                  >Vai a dettaglio</a>
                )}
                <button
                  className="px-3 py-1 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 text-xs"
                  onClick={() => setModalNotifica(null)}
                >Chiudi</button>
              </div>
            </div>
            {/* --- CSS keyframes per animazione popup --- */}
            <style>{`
              @keyframes popIn {
                0% { transform: scale(0.93); opacity: 0; }
                60% { transform: scale(1.04); }
                100% { transform: scale(1); opacity: 1; }
              }
              .animate-pop { animation: popIn 0.25s cubic-bezier(.41,1.4,.67,.97) both; }
            `}</style>
          </div>
        )}
      </main>
    </div>
  );
}
