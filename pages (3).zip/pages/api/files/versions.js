// Percorso: /pages/api/files/versions.js
import db from "../../../db/db.js";

function copyFileRelations(fromId, toId) {
  // TAGS
  db.prepare("SELECT tag_id FROM files_tags WHERE file_id=?")
    .all(fromId).forEach(({ tag_id }) =>
      db.prepare("INSERT INTO files_tags (file_id, tag_id) VALUES (?,?)").run(toId, tag_id));
  // USERS
  db.prepare("SELECT user_id FROM files_users WHERE file_id=?")
    .all(fromId).forEach(({ user_id }) =>
      db.prepare("INSERT INTO files_users (file_id, user_id) VALUES (?,?)").run(toId, user_id));
  // TEAMS
  db.prepare("SELECT team_id FROM files_teams WHERE file_id=?")
    .all(fromId).forEach(({ team_id }) =>
      db.prepare("INSERT INTO files_teams (file_id, team_id) VALUES (?,?)").run(toId, team_id));
  // PROJECTS
  db.prepare("SELECT project_id FROM files_projects WHERE file_id=?")
    .all(fromId).forEach(({ project_id }) =>
      db.prepare("INSERT INTO files_projects (file_id, project_id) VALUES (?,?)").run(toId, project_id));
  // CLIENTS (se esiste tabella)
  try {
    db.prepare("SELECT client_id FROM files_clients WHERE file_id=?")
      .all(fromId).forEach(({ client_id }) =>
        db.prepare("INSERT INTO files_clients (file_id, client_id) VALUES (?,?)").run(toId, client_id));
  } catch {}
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Solo POST" });

  const multiparty = (await import("multiparty")).default;
  const form = new multiparty.Form();

  form.parse(req, async function (err, fields, files) {
    if (err) return res.status(500).json({ error: "Errore upload", details: err.message });
    const file_id = fields.file_id?.[0];
    if (!file_id) return res.status(400).json({ error: "file_id obbligatorio" });
    const note = fields.note?.[0] || "";
    const uploaded_by = fields.uploaded_by?.[0] || null;
    const fileObj = files.file?.[0];
    if (!fileObj) return res.status(400).json({ error: "File mancante" });

    // Upload fisico
    const path = require("path");
    const fs = require("fs");
    const uploadsDir = path.join(process.cwd(), "uploads");
    if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);
    const ext = path.extname(fileObj.originalFilename);
    const newFilename = `${Date.now()}_${Math.floor(Math.random()*99999)}${ext}`;
    const destPath = path.join(uploadsDir, newFilename);
    fs.copyFileSync(fileObj.path, destPath);

    // File precedente
    const fileOld = db.prepare("SELECT * FROM files WHERE id=?").get(file_id);
    if (!fileOld) return res.status(404).json({ error: "File precedente non trovato" });

    // Nuovo record file (nuova versione)
    const insert = db.prepare(`
      INSERT INTO files (name, path, mimetype, size, note, created_at, uploaded_by, folder_id)
      VALUES (?, ?, ?, ?, ?, datetime('now'), ?, ?)
    `);
    const info = insert.run(
      fileOld.name,
      `/uploads/${newFilename}`,
      fileObj.headers["content-type"] || fileOld.mimetype,
      fileObj.size,
      note || fileOld.note || "",
      uploaded_by,
      fileOld.folder_id
    );
    const newFileId = info.lastInsertRowid;

    // Copia tutte le relazioni
    copyFileRelations(file_id, newFileId);

    // Log: nuova versione
    db.prepare("INSERT INTO file_logs (file_id, action, user_id, timestamp, note) VALUES (?, ?, ?, datetime('now'), ?)")
      .run(newFileId, "version_upload", uploaded_by, "Nuova versione caricata da " + (uploaded_by || "-"));

    res.json({ success: true, file_id: newFileId });
  });
}
