// Percorso: /pages/components/FileVersionsModal.js
import { useEffect, useState } from "react";
import axios from "axios";

export default function FileVersionsModal({ file, onClose }) {
  const [versions, setVersions] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [note, setNote] = useState("");
  const [fileInput, setFileInput] = useState(null);

  useEffect(() => {
    axios.get(`/api/files/versions?file_id=${file.id}`).then(res => setVersions(res.data));
  }, [file.id, uploading]);

  const handleUpload = async e => {
    e.preventDefault();
    if (!fileInput) return;
    setUploading(true);
    const form = new FormData();
    form.append("file_id", file.id);
    form.append("note", note);
    form.append("file", fileInput.files[0]);
    form.append("uploaded_by", 1); // Sostituisci con ID utente loggato se disponibile
    await axios.post(`/api/files/versions?file_id=${file.id}`, form);
    setUploading(false); setFileInput(null); setNote("");
  };

  const handleRestore = async version_id => {
    await axios.put(`/api/files/versions?restore=1`, { version_id });
    onClose(true); // chiude modale e aggiorna file
  };

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh",
      background: "rgba(0,0,30,0.16)", zIndex: 99, display: "flex",
      alignItems: "center", justifyContent: "center"
    }}>
      <div style={{
        background: "#fff", borderRadius: 16, boxShadow: "0 2px 24px #b3baf0",
        padding: 30, maxWidth: 540, minWidth: 340, minHeight: 250, position: "relative"
      }}>
        <button onClick={() => onClose()} style={{
          position: "absolute", right: 18, top: 10, background: "none", border: "none", fontSize: 24, cursor: "pointer"
        }}>✖</button>
        <h3 style={{ color: "#223", margin: 0, fontWeight: 700 }}>Storico versioni</h3>
        <ul style={{ listStyle: "none", padding: 0 }}>
          {versions.map(v => (
            <li key={v.id} style={{
              margin: "12px 0", background: "#f8faff", borderRadius: 10, padding: 12, display: "flex", alignItems: "center"
            }}>
              <div style={{ flex: 1 }}>
                <b>v{v.version_number}</b> – {v.uploaded_at?.slice(0, 16).replace("T", " ")}<br />
                <span style={{ color: "#333" }}>{v.filename}</span>
                {v.note && <div style={{ fontSize: 12, color: "#888" }}>Nota: {v.note}</div>}
              </div>
              <button onClick={() => window.open(`/api/download?path=${encodeURIComponent(v.path)}`)} style={{
                marginRight: 8, background: "#f3f5ff", border: "1px solid #b3c6ff", borderRadius: 7, padding: "5px 12px", fontWeight: 600, cursor: "pointer"
              }}>Scarica</button>
              <button onClick={() => handleRestore(v.id)} style={{
                background: "#e5faee", border: "1px solid #9ecbb3", borderRadius: 7, padding: "5px 12px", fontWeight: 600, cursor: "pointer"
              }}>Ripristina</button>
            </li>
          ))}
        </ul>
        <form onSubmit={handleUpload} style={{ marginTop: 12 }}>
          <input type="file" ref={ref => setFileInput(ref)} style={{ marginBottom: 6 }} />
          <input type="text" value={note} placeholder="Nota (facoltativa)" onChange={e => setNote(e.target.value)} style={{
            border: "1px solid #eaeaea", borderRadius: 7, padding: "4px 8px", marginLeft: 10
          }} />
          <button type="submit" disabled={uploading}
            style={{ marginLeft: 12, background: "#cff2e0", border: "1px solid #9ecbb3", borderRadius: 7, padding: "5px 14px", fontWeight: 600 }}>
            {uploading ? "Carico..." : "Carica nuova versione"}
          </button>
        </form>
      </div>
    </div>
  );
}
