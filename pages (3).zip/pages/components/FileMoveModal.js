import { useEffect, useState } from "react";
import axios from "axios";

export default function FileMoveModal({ file, folders, onClose }) {
  const [dest, setDest] = useState(file.folder_id || "");
  const [moving, setMoving] = useState(false);

  const handleMove = async () => {
    setMoving(true);
    await axios.post("/api/files/move", { file_id: file.id, folder_id: dest });
    setMoving(false);
    onClose(true);
  };

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh",
      background: "rgba(0,0,30,0.16)", zIndex: 99, display: "flex",
      alignItems: "center", justifyContent: "center"
    }}>
      <div style={{
        background: "#fff", borderRadius: 16, boxShadow: "0 2px 24px #b3baf0",
        padding: 24, maxWidth: 380, minWidth: 300, position: "relative"
      }}>
        <button onClick={() => onClose()} style={{
          position: "absolute", right: 12, top: 8, background: "none", border: "none", fontSize: 22, cursor: "pointer"
        }}>✖</button>
        <h3>Sposta file in cartella</h3>
        <select value={dest} onChange={e => setDest(e.target.value)} style={{ width: "100%", margin: "18px 0", padding: 7, borderRadius: 8 }}>
          {folders.map(f =>
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          )}
        </select>
        <button disabled={moving} onClick={handleMove}
          style={{ width: "100%", background: "#f3f5ff", border: "1px solid #b3c6ff", borderRadius: 7, padding: "10px 0", fontWeight: 600 }}>
          {moving ? "Spostamento..." : "Sposta"}
        </button>
      </div>
    </div>
  );
}
