///pages/api/files/download.js

import JSZip from "jszip";
import fs from "fs";
import path from "path";

// Es: i file sono in /uploads o simile
const UPLOAD_DIR = path.join(process.cwd(), "uploads");

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const { fileIds } = req.body;
  if (!Array.isArray(fileIds) || !fileIds.length) {
    return res.status(400).json({ error: "fileIds obbligatorio" });
  }

  const zip = new JSZip();
  for (const fileId of fileIds) {
    // Prendi dal DB il percorso vero del file!
    // Qui solo esempio:
    const filePath = path.join(UPLOAD_DIR, `${fileId}`); // <-- sostituisci con il nome giusto
    const exists = fs.existsSync(filePath);
    if (exists) {
      zip.file(path.basename(filePath), fs.readFileSync(filePath));
    }
  }
  const content = await zip.generateAsync({ type: "nodebuffer" });
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", "attachment; filename=files.zip");
  res.end(content);
}
