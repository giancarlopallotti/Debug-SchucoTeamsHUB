///pages/api/files/info.js
import { query } from "../../../lib/db";

export default async function handler(req, res) {
  const { file_id } = req.query;
  if (!file_id) return res.status(400).json({ error: "file_id obbligatorio" });
  // Ottieni tutte le info: file, utente, download, release, ecc.
  // Esempio (personalizza query):
  const [file] = await query("SELECT * FROM files WHERE id=?", [file_id]);
  const downloads = await query("SELECT * FROM file_downloads WHERE file_id=?", [file_id]);
  const releases = await query("SELECT * FROM file_releases WHERE file_id=?", [file_id]);
  // Altre join...
  res.json({ ...file, downloads, releases });
}
