// Percorso: /components/files/FileTable.js

import React, { useState } from "react";

// Tooltip di base
const Tooltip = ({ children, tip }) => (
  <span style={{ position: "relative", cursor: "help" }}>
    {children}
    <span style={{
      visibility: "hidden",
      background: "#333",
      color: "#fff",
      textAlign: "center",
      borderRadius: 5,
      padding: "2px 7px",
      position: "absolute",
      zIndex: 9,
      bottom: "110%",
      left: "50%",
      marginLeft: "-60px",
      width: 120,
      fontSize: 11,
      opacity: 0,
      transition: "opacity 0.2s"
    }}
    className="tooltip-text"
    >{tip}</span>
    <style>
      {`
      span[style][class]:hover .tooltip-text {
        visibility: visible;
        opacity: 1;
      }
      `}
    </style>
  </span>
);

const badge = (label, color, key) => (
  <span
    key={key}
    style={{
      display: "inline-block",
      background: color.bg,
      color: color.txt,
      borderRadius: 8,
      fontSize: 12,
      fontWeight: 500,
      margin: "0 2px 2px 0",
      padding: "2.5px 9px",
      minWidth: 0,
      whiteSpace: "nowrap"
    }}
  >{label}</span>
);

const colorMap = {
  tag: { bg: "#e3e6fa", txt: "#263b8a" },
  team: { bg: "#d8f2e0", txt: "#137956" },
  user: { bg: "#e7e0fa", txt: "#563fa6" },
  project: { bg: "#fff3d2", txt: "#a47319" },
  client: { bg: "#fce5e0", txt: "#a02222" }
};

// Emoji per icone azioni
const Eye = () => <span title="Anteprima">👁️</span>;
const Info = () => <span title="Info">ℹ️</span>;
const Pencil = () => <span title="Modifica">✏️</span>;
const Trash = () => <span title="Elimina">🗑️</span>;
const Download = () => <span title="Download">⬇️</span>;
const More = () => <span title="Altre azioni">⋮</span>;

// Funzione per scaricare i file selezionati (dummy, da integrare backend)
function handleDownloadSelected(selectedFiles) {
  if (selectedFiles.length === 0) return alert("Nessun file selezionato!");
  fetch("/api/files/download", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fileIds: selectedFiles }),
  })
    .then(res => res.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "files.zip";
      a.click();
      window.URL.revokeObjectURL(url);
    });
}

export default function FileTable({
  files, tags, teams, users, projects, clients,
  selectedFiles, toggleSelect, selectAll, clearSelect,
  onEdit, onPreview, onInfo, onDelete
}) {
  const [sortField, setSortField] = useState("name");
  const [sortAsc, setSortAsc] = useState(true);

  // Sort handler
  function handleSort(field) {
    if (field === sortField) setSortAsc(s => !s);
    else { setSortField(field); setSortAsc(true); }
  }

  // Sorted files
  const sortedFiles = [...files].sort((a, b) => {
    let av = a[sortField] || "";
    let bv = b[sortField] || "";
    if (sortField === "created_at") { av = av || ""; bv = bv || ""; }
    if (typeof av === "string") av = av.toLowerCase();
    if (typeof bv === "string") bv = bv.toLowerCase();
    if (av < bv) return sortAsc ? -1 : 1;
    if (av > bv) return sortAsc ? 1 : -1;
    return 0;
  });

  return (
    <div style={{ marginTop: 18 }}>
      {/* Barra sopra tabella */}
      <div style={{ marginBottom: 7, display: "flex", alignItems: "center", gap: 14 }}>
        <b style={{ fontSize: 18, color: "#2a428a", letterSpacing: 0.3 }}>Percorso corrente</b>
        <span style={{ color: "#425", fontSize: 16, fontWeight: 600 }}>File trovati: {files.length}</span>
        <button
          onClick={() => handleDownloadSelected(selectedFiles)}
          style={{
            marginLeft: 6,
            fontSize: 13,
            background: "#ddeeff",
            border: "none",
            borderRadius: 7,
            padding: "6px 18px",
            cursor: "pointer",
            color: "#2a428a",
            fontWeight: 600
          }}
          disabled={selectedFiles.length === 0}
        >
          <Download /> Download selezionati
        </button>
        <button onClick={selectAll} style={{ marginLeft: 12, fontSize: 13, background: "#eef3ff", border: "none", borderRadius: 7, padding: "5px 12px", cursor: "pointer" }}>Seleziona tutti</button>
        <button onClick={clearSelect} style={{ marginLeft: 7, fontSize: 13, background: "#ffeaea", border: "none", borderRadius: 7, padding: "5px 12px", cursor: "pointer", color: "#a02222" }}>Deseleziona</button>
        {selectedFiles.length > 0 && (
          <span style={{ marginLeft: 10, fontSize: 14, color: "#15671a", fontWeight: 600 }}>
            {selectedFiles.length} selezionati
          </span>
        )}
      </div>
      <div style={{
        overflowX: "auto",
        borderRadius: 8,
        border: "1.5px solid #e3e6fa",
        boxShadow: "0 2px 8px #f8faff",
        background: "#fff"
      }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 15 }}>
          <thead style={{ background: "#f5f6fd" }}>
            <tr>
              <th style={{ width: 28 }}></th>
              <th style={{ textAlign: "left", padding: "9px 8px", cursor: "pointer" }} onClick={() => handleSort("name")}>
                Nome {sortField === "name" && (sortAsc ? "▲" : "▼")}
              </th>
              <th style={{ cursor: "pointer" }} onClick={() => handleSort("note")}>
                Note {sortField === "note" && (sortAsc ? "▲" : "▼")}
              </th>
              <th>Tag</th>
              <th>Team</th>
              <th>Utenti</th>
              <th>Progetti</th>
              <th>Aziende</th>
              <th style={{ cursor: "pointer" }} onClick={() => handleSort("created_at")}>
                Data {sortField === "created_at" && (sortAsc ? "▲" : "▼")}
              </th>
              <th>Azioni</th>
            </tr>
          </thead>
          <tbody>
            {sortedFiles.length === 0 && (
              <tr>
                <td colSpan={10} style={{ textAlign: "center", color: "#aaa", padding: 28, fontSize: 16 }}>
                  Nessun file trovato.
                </td>
              </tr>
            )}
            {sortedFiles.map(file => (
              <tr key={file.id} style={{
                background: selectedFiles.includes(file.id) ? "#e8ebfa" : "transparent"
              }}>
                <td style={{ textAlign: "center" }}>
                  <input
                    type="checkbox"
                    checked={selectedFiles.includes(file.id)}
                    onChange={() => toggleSelect(file.id)}
                  />
                </td>
                {/* Nome file */}
                <td style={{ fontWeight: 500, color: "#293562", padding: "7px 8px" }}>
                  {/\.(pdf)$/i.test(file.name) ? "📄"
                    : /\.(jpe?g|png|gif)$/i.test(file.name) ? "🖼️"
                    : /\.(xls|xlsx)$/i.test(file.name) ? "📊"
                    : "📎"
                  }
                  {" "}
                  {file.name}
                </td>
                {/* Note */}
                <td style={{ color: "#626", fontSize: 14, maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {file.note || "-"}
                </td>
                {/* Tag */}
                <td>
                  {(file.tags || []).map(t =>
                    <div key={t.id || t} style={{ marginBottom: 3 }}>
                      {badge("#" + (t.name || t), colorMap.tag, t.id || t)}
                    </div>
                  )}
                </td>
                {/* Team */}
                <td>
                  {(file.teams || []).map(t =>
                    <div key={t.id || t} style={{ marginBottom: 3 }}>
                      {badge(t.name || t, colorMap.team, t.id || t)}
                    </div>
                  )}
                </td>
                {/* Utenti */}
                <td>
                  {(file.users || []).length === 0
                    ? <span style={{ color: "#bbb" }}>-</span>
                    : (file.users || []).map(u =>
                      <div key={u.id} style={{ marginBottom: 3 }}>
                        {badge((u.surname ? u.surname + " " : "") + u.name, colorMap.user, u.id)}
                      </div>
                    )
                  }
                </td>
                {/* Progetti */}
                <td>
                  {(file.projects || []).map(p =>
                    <div key={p.id || p} style={{ marginBottom: 3 }}>
                      {badge(p.title || p.name, colorMap.project, p.id || p)}
                    </div>
                  )}
                </td>
                {/* Aziende */}
                <td>
                  {(file.clients || []).map(c =>
                    <div key={c.id || c} style={{ marginBottom: 3 }}>
                      {badge(c.company, colorMap.client, c.id || c)}
                    </div>
                  )}
                </td>
                {/* Data */}
                <td>
                  <span style={{ color: "#666" }}>{file.created_at?.slice(0, 10) || "-"}</span>
                </td>
                {/* Azioni */}
                <td>
                  <Tooltip tip="Anteprima">
                    <button onClick={() => onPreview && onPreview(file)}
                      style={btnActionStyle}
                    ><Eye /></button>
                  </Tooltip>
                  <Tooltip tip="Info dettagliate">
                    <button onClick={() => onInfo && onInfo(file)}
                      style={btnActionStyle}
                    ><Info /></button>
                  </Tooltip>
                  <Tooltip tip="Modifica">
                    <button onClick={() => onEdit(file)}
                      style={btnActionStyle}
                    ><Pencil /></button>
                  </Tooltip>
                  <Tooltip tip="Elimina file">
                    <button
                      onClick={() => {
                        if (window.confirm("Sei sicuro di voler eliminare questo file?")) onDelete && onDelete(file);
                      }}
                      style={{ ...btnActionStyle, color: "#d22" }}
                    ><Trash /></button>
                  </Tooltip>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const btnActionStyle = {
  background: "none",
  border: "none",
  fontSize: 20,
  margin: "0 2px",
  cursor: "pointer",
  padding: 3,
  verticalAlign: "middle"
};
